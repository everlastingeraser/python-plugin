"""Skeleton for py.path.

Project: py 1.4.31 <https://bitbucket.org/pytest-dev/py>
Skeleton by: Aleks Bunin <github@compuix.com>
"""

from . import path
from . import error
import py.error as error
